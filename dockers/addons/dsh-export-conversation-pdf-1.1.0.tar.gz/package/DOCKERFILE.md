# Docker requirements

The plugin intentionally does not bundle Chrome/Chromium or Linux shared libraries.
For `node:24-bookworm` / Debian 12 install Chromium through APT so Debian owns and
updates all of its runtime libraries.

```dockerfile
USER root

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        chromium \
        chromium-sandbox \
        ca-certificates \
    && rm -rf /var/lib/apt/lists/*

ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium
```

If your image later switches back to an unprivileged user, keep that `USER ...`
line after the block, for example:

```dockerfile
USER node
```

The plugin uses the Chromium sandbox for non-root runtime users. When DSH must run
as root, Chromium cannot use its normal sandbox and the renderer adds `--no-sandbox`.
For unusual container security profiles where Chromium's sandbox is unavailable even
for a non-root user, set:

```dockerfile
ENV DSH_PDF_CHROME_NO_SANDBOX=1
```

Use that fallback only when necessary.
